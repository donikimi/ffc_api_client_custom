library(testthat)
library(ffcAPIClient)

test_check("ffcAPIClient")
